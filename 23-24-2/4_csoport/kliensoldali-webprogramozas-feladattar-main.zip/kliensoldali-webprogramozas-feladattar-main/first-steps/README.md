## Kezdeti lépések

Telepítés és első lépések. Ehhez szükséged lesz egy feltelepített [Node.js](https://nodejs.org/en/) környezetre!

1. Telepíts egy React alkalmazást:
    - a [Create-React-App](https://create-react-app.dev/) segítségével, vagy
    - a [Vite](https://vitejs.dev/guide/#scaffolding-your-first-vite-project) segítségével!
2. Telepítés után indítsd el! (`npm start` vagy `npm run dev`)
3. Elemezd a legenerált könyvtárstruktúrát és a fájlok tartalmát!
4. Végezz el egyszerűbb módosításokat a fájlokon, és figyeld meg hatásukat!
