import { Haiku } from "./features/haiku/Haiku";

const App = () => <Haiku />;

export default App;
