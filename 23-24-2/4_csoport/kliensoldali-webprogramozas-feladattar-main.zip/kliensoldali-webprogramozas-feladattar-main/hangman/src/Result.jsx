const Result = () => {
  const wrong = 3;
  const maxTips = 9;
  return (
    <div id="eredmeny">
      {wrong}/{maxTips}
    </div>
  );
};

export default Result;
