const Buttons = () => {
  return (
    <div id="betuk">
      <button disabled={false}>a</button>
      <button disabled={true}>b</button>
    </div>
  );
};

export default Buttons;
