# Aktuális idő

Készíts egy komponenst, amely kiírja az aktuális időt így: "The current local time is: #time#"!

1. Jelenítsd meg ezt a komponenst!
2. A `ReactDOM.render()` hívást ismételd másodeprcenként!
3. Nyisd meg a webfejlesztési eszköztárat és elemezd, hogy milyen változások történnek a DOM-ban!
