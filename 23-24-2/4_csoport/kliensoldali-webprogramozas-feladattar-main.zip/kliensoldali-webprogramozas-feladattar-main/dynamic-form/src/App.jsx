function App() {
  return <h1>Template</h1>;
}

export default App;
