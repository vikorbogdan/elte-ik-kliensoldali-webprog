# Dinamikus űrlap

Készíts egy olyan komponenst, amely egy olyan űrlapot tartalmaz, amiben dinamikusan tudunk mezőket felvenni!

Tegyük fel, hogy barátainkat szeretnénk felvenni, és ehhez egy olyan felhasználói felületet álmodtunk meg, ahol egy gomb hozzáadásával újabb és újabb szöveges beviteli mező jelenik meg. Az űrlap elküldésekor adja ki ez a komponens barátaink nevének listáját!
