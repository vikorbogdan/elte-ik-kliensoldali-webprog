# Véletlen háttérszín

Készíts egy komponenst, amely egy `div` háttérszínét valamilyen véletlen értékre állítja be!

1. Jelenítsd meg ezt a komponenst!
2. A `ReactDOM.render()` hívást tedd egy ismétlődő időzítő belsejébe!
3. Nyisd meg a webfejlesztési eszköztárat és elemezd, hogy milyen változások történnek a DOM-ban!
