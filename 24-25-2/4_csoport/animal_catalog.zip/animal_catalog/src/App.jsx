import { AnimalListPage } from "./pages/AnimalListPage";

function App() {
  return <AnimalListPage />;
}

export default App;
